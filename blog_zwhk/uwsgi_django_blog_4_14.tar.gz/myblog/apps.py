from django.apps import AppConfig


class BlogConfig(AppConfig):
    name = 'myblog'

